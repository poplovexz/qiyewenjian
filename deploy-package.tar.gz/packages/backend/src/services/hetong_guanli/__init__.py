"""
合同管理模块服务
"""
from .hetong_moban_service import HetongMobanService

__all__ = [
    "HetongMobanService"
]
