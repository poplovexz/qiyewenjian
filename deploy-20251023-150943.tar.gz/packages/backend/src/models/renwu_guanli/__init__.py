"""
任务管理模块数据模型
"""
from .renwu import Renwu

__all__ = [
    "Renwu"
]
