"""
客户管理模块数据模型
"""
from .kehu import Kehu
from .fuwu_jilu import FuwuJilu

__all__ = [
    "Kehu",
    "FuwuJilu"
]
