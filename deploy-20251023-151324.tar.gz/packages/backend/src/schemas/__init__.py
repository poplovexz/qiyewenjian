"""
Pydantic 模式定义
"""
