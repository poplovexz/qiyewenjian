"""
服务管理模块服务
"""
from .fuwu_gongdan_service import FuwuGongdanService

__all__ = [
    "FuwuGongdanService"
]
