"""
服务管理模块 API endpoints
"""
from . import fuwu_gongdan

__all__ = [
    "fuwu_gongdan"
]
