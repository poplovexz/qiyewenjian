# Legacy Simple Server 文档

## 📋 概述

这个文档记录了已被模块化重构替代的旧版单体服务器实现。

## 🗂️ 旧版文件信息

### 原始文件
- **文件名**: `simple_server.py`
- **大小**: 1400+ 行代码
- **最后有效提交**: `3c6642c` - fix: 成功修复正式版后端服务启动问题
- **移除日期**: 2025-09-20
- **移除原因**: 已被模块化结构完全替代

### 文件内容概述
旧版 `simple_server.py` 包含了以下功能（现已分拆到模块化结构中）：

1. **用户管理** - 现在位于 `app/routers/users.py`
2. **权限管理** - 现在位于 `app/routers/permissions.py`
3. **角色管理** - 现在位于 `app/routers/roles.py`
4. **线索管理** - 现在位于 `app/routers/leads.py`
5. **审计管理** - 现在位于 `app/routers/audit.py`
6. **合同管理** - 现在位于 `app/routers/contracts.py`
7. **产品管理** - 现在位于 `app/routers/products.py`
8. **客户管理** - 现在位于 `app/routers/customers.py`
9. **支付管理** - 现在位于 `app/routers/payments.py`
10. **审核规则** - 现在位于 `app/routers/audit_rules.py`

## 🔄 迁移到新结构

### 新的模块化结构
```
packages/backend/app/
├── main.py              # 主应用入口
├── utils.py             # 工具函数
├── data/                # 数据模块
│   ├── users.py
│   ├── permissions.py
│   ├── roles.py
│   ├── contracts.py
│   ├── products.py
│   ├── customers.py
│   └── ...
└── routers/             # 路由模块
    ├── auth.py
    ├── users.py
    ├── permissions.py
    ├── roles.py
    ├── leads.py
    ├── audit.py
    ├── contracts.py
    ├── products.py
    ├── customers.py
    ├── payments.py
    └── audit_rules.py
```

### 启动方式变更
- **旧版**: `python3 simple_server.py`
- **新版**: `python3 run_server.py`

## 📚 相关文档

- **新版文档**: `README_SIMPLE.md` (已更新为模块化结构说明)
- **主文档**: `README.md`
- **Git历史**: 可通过 `git show 3c6642c:packages/backend/simple_server.py` 查看旧版文件

## ⚠️ 重要说明

1. **不要恢复旧文件**: 旧版 `simple_server.py` 已经过时，包含的API实现可能与当前前端不兼容
2. **使用新结构**: 所有新的开发和维护都应该在 `app/` 模块化结构中进行
3. **API兼容性**: 新的模块化结构保持了与前端的完全兼容性
4. **性能优化**: 新结构支持更好的代码组织、测试和维护

## 🔗 Git 引用

如需查看旧版文件的完整内容，可以使用以下Git命令：

```bash
# 查看旧版文件内容
git show 3c6642c:packages/backend/simple_server.py

# 查看旧版文件的修改历史
git log --follow packages/backend/simple_server.py
```

---

**注意**: 此文档仅作为历史记录保存，实际开发请使用新的模块化结构。
