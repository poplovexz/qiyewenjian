"""
用户管理服务模块
"""
from .auth_service import AuthService

__all__ = [
    "AuthService"
]
